import React, { useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';

export default function App() {
  const [data, setData] = useState(null);

  // TODO 1: Implement 3D Object Placement functionality

  return (
    <View style={styles.container}>
      <Text style={styles.title}>3D Object Placement</Text>
      <Text style={styles.description}>Template for Activity 07</Text>

      {/* // TODO 2: Add UI components here */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    color: '#666',
  },
});

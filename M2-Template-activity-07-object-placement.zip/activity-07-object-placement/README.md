# Object Placement

> **🛠️ Stack for this lesson** — Expo SDK 54 / React Native 0.79 + native platform APIs · runs in Expo Go / dev client on a real phone.
> 📥 Template: [/learn/m2/template/activity-07-object-placement](/learn/m2/template/activity-07-object-placement)

Builds on the AR camera. You'll listen for taps on the camera view and drop a virtual "object" (initially a styled `<View>` or emoji) at the tap point.

**Time:** ~30 minutes · **Concept:** Concept 07 — Tap-to-Place AR Anchors

---

## What You'll Build

| # | TODO | File |
|---|------|------|
| 1 | Capture tap coordinates on the `<CameraView>` using a gesture handler | `App.js` |
| 2 | Push each tap into a `placedObjects` state array | `App.js` |
| 3 | Render each placed object as an absolutely-positioned overlay at its tap coordinate | `App.js` |

There are no commented-out solutions in the code. Read what's already there, infer what each TODO is asking for, and write it.

## Run It

```bash
npm install --legacy-peer-deps
npx expo start
```

Scan the QR code with **Expo Go** on a phone that's on the same Wi-Fi as your computer. On iOS use the Camera app; on Android open Expo Go and scan from there.

Use `react-native-gesture-handler` if `onPress` doesn't give you tap coordinates.

## Verify

Your activity is done when, on a real device:

- [ ] Tapping the screen drops a visible object at the tap location.
- [ ] Multiple taps create multiple objects without removing the earlier ones.
- [ ] A clear button removes all objects.
- [ ] Objects stay positioned correctly when you rotate the device.

## Stretch

Pick one and write a short note in your reflection about what you tried:
- Make objects draggable after being placed.
- Cycle through 3 different object types with a picker.
- Persist placed objects across app restarts via `AsyncStorage`.

## 🪞 Reflect on Your Work

Answer in 2-3 sentences each, in this README under your TODO commits. Your tutor reads these as part of grading.

1. **What did you learn that you didn't know before?** Name the most surprising thing — a permission quirk, a platform difference, a debugging story.
2. **How did you collaborate with AI?** If you used Claude / ChatGPT / Cursor / Copilot, what part of the work did *you* contribute — the prompt, the verification, the design decision, the bug-fix? If you didn't use AI, what was the hardest thing to figure out alone?
3. **How do you know your code works?** Describe one specific thing you did to confirm — the device test you ran, the screenshot you took, the behavior you watched.

> AI is a great collaborator. Owning your thinking, verifying the output, and explaining your design choices is what *learning* looks like in this course.

## 📱 Device Evidence (required, 30% of grade)

You'll only get full marks if the activity runs on a real device — not just Expo's web preview or a simulator.

Submit a `device-evidence/` folder containing:

> **📓 Where this lives now:** open your lesson note for this activity.
> Click **Take Notes** at the top of the lesson page if you don't already have a note —
> it creates one titled `<Lesson title> — <COURSE>` with a scaffold pre-filled from
> the lesson headings. Add an H2 section titled **`Device Notes`** to that note and put
> your work there. The note persists across devices and is queryable by the AI Tutor.
>
> 💡 **Tip:** open the AI Tutor while viewing your note and ask
> *"help me draft my Device Notes for this activity"*. The Tutor will append a draft to your note;
> you can drag it into the **Device Notes** section if it lands elsewhere.

1. **`screenshot-portrait.png`** — One full-screen screenshot from your real device, portrait orientation, with the device's status bar visible (clock + battery prove it's a real device).
2. **`recording.mp4`** — 30–60 second screen recording of your real device showing tapping the camera preview to drop at least 3 objects, then clearing and re-placing them. Use iOS Screen Recording (Control Center → ⏺) or Android `adb shell screenrecord`.
3. **Device Notes in your lesson note** — instead of a local `DEVICE-NOTES.md` file, add an H2 section titled **`Device Notes`** to your lesson note (click **Take Notes** at the top of the lesson page if you don't have a note yet). Cover, in 80–150 words:
   - What device did you test on? (model + OS version)
   - What worked first try?
   - What broke, and what error message did you see? (Quote the exact error.)
   - What did you only notice on a real device that you'd have missed in the simulator?

Grading: 70% feature works in code, 30% device evidence. "I tested in Expo Go web" is not device evidence.

## Submit

When the Verify checklist is green, head to **[/learn/m2/certification](/learn/m2/certification)** and submit your activity link. Include 1–2 screenshots of the running app on your device (plus the `device-evidence/` folder).

<!-- claude-template-fix: readme-v3 -->

<!-- claude-template-fix: notes-migration-v1 -->
